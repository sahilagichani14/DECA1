package analysis.exercise;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import com.google.common.collect.Sets;

import analysis.TaintAnalysisFlowFunctions;
import analysis.VulnerabilityReporter;
import analysis.fact.DataFlowFact;
import heros.FlowFunction;
import soot.*;
import soot.jimple.AssignStmt;
import soot.jimple.InstanceInvokeExpr;
import soot.jimple.Stmt;
import soot.jimple.internal.*;

public class Exercise1FlowFunctions extends TaintAnalysisFlowFunctions {

    private VulnerabilityReporter reporter;

    public Exercise1FlowFunctions(VulnerabilityReporter reporter) {
        this.reporter = reporter;
    }

    @Override
    public FlowFunction<DataFlowFact> getCallFlowFunction(Unit callSite, SootMethod callee) {
        return new FlowFunction<DataFlowFact>() {
            @Override
            public Set<DataFlowFact> computeTargets(DataFlowFact fact) {
                if (fact.equals(DataFlowFact.zero()))
                    return Collections.emptySet();
                prettyPrint(callSite, fact);
                Set<DataFlowFact> out = Sets.newHashSet();
                if (!(callSite instanceof Stmt)) {
                    return out;
                }
                Stmt callSiteStmt = (Stmt) callSite;
                //TODO: Implement Exercise 1c) here
                if (callSiteStmt instanceof JInvokeStmt) {
                    List<Value> argBoxes = callSiteStmt.getInvokeExpr().getArgs();
                    for (int i = 0; i < (argBoxes.size()); i++) {
                        Value arg = callSiteStmt.getInvokeExpr().getArg(i);
                        if (fact.getVariable() == arg) {
                            Local actualParameter = callee.getActiveBody().getParameterLocal(i);
                            DataFlowFact vul = new DataFlowFact(actualParameter);
                            out.add(vul);
                        }
                    }

                }
                // END of Implementation
                return out;
            }
        };
    }

    public FlowFunction<DataFlowFact> getCallToReturnFlowFunction(final Unit call, Unit returnSite) {
        return new FlowFunction<DataFlowFact>() {

            @Override
            public Set<DataFlowFact> computeTargets(DataFlowFact val) {

                Set<DataFlowFact> out = Sets.newHashSet();
                Stmt callSiteStmt = (Stmt) call;
                out.add(val);
                modelStringOperations(val, out, callSiteStmt);

                if (val.equals(DataFlowFact.zero())) {

                    //TODO: Implement Exercise 1a) here
                    if (callSiteStmt instanceof JAssignStmt) {
                        Local leftOP = (Local) ((JAssignStmt) callSiteStmt).getLeftOp();
                        Value rightOP = ((JAssignStmt) callSiteStmt).getRightOp();
                        if (rightOP instanceof JVirtualInvokeExpr) {
                            SootMethod method = ((JVirtualInvokeExpr) rightOP).getMethod();
                            if (Objects.equals(method.getName(), "getParameter")) {
                                DataFlowFact vul = new DataFlowFact(leftOP);
                                out.add(vul);
                            }
                        }


                    }
                    // END of Implementation
                }
                if (call instanceof Stmt && call.toString().contains("executeQuery")) {
                    Stmt stmt = (Stmt) call;
                    Value arg = stmt.getInvokeExpr().getArg(0);
                    if (val.getVariable().equals(arg)) {
                        reporter.reportVulnerability();
                    }
                }
                return out;
            }
        };
    }

    private void modelStringOperations(DataFlowFact fact, Set<DataFlowFact> out,
                                       Stmt callSiteStmt) {
        if (callSiteStmt instanceof AssignStmt && callSiteStmt.toString().contains("java.lang.StringBuilder append(") && callSiteStmt.getInvokeExpr() instanceof InstanceInvokeExpr) {
            Value arg0 = callSiteStmt.getInvokeExpr().getArg(0);
            Value base = ((InstanceInvokeExpr) callSiteStmt.getInvokeExpr()).getBase();
            /*Does the propagated value match the first parameter of the append call or the base variable*/
            if (fact.getVariable().equals(arg0) || fact.getVariable().equals(base)) {
                /*Yes, then taint the left side of the assignment*/
                Value leftOp = ((AssignStmt) callSiteStmt).getLeftOp();
                if (leftOp instanceof Local) {
                    out.add(new DataFlowFact((Local) leftOp));
                }
            }
        }


        /*For any call x = var.toString(), if the base variable var is tainted, then x is tainted.*/
        if (callSiteStmt instanceof AssignStmt && callSiteStmt.toString().contains("toString()")) {
            if (callSiteStmt.getInvokeExpr() instanceof InstanceInvokeExpr) {
                InstanceInvokeExpr instanceInvokeExpr = (InstanceInvokeExpr) callSiteStmt.getInvokeExpr();
                if (fact.getVariable().equals(instanceInvokeExpr.getBase())) {
                    Value leftOp = ((AssignStmt) callSiteStmt).getLeftOp();
                    if (leftOp instanceof Local) {
                        out.add(new DataFlowFact((Local) leftOp));
                    }
                }
            }
        }
    }

    @Override
    public FlowFunction<DataFlowFact> getNormalFlowFunction(final Unit curr, Unit succ) {
        return new FlowFunction<DataFlowFact>() {
            @Override
            public Set<DataFlowFact> computeTargets(DataFlowFact fact) {
                prettyPrint(curr, fact);
                Set<DataFlowFact> out = Sets.newHashSet();
                out.add(fact);
                //TODO: Implement Exercise 1b) here
                if (!fact.equals(DataFlowFact.zero())) {
                    if (curr instanceof JAssignStmt) {
                        Value rightOP = ((JAssignStmt) curr).getRightOp();
                        Local leftOP = (Local) ((JAssignStmt) curr).getLeftOp();
                        Local var = fact.getVariable();
                        if (var == rightOP) {
                            DataFlowFact vul = new DataFlowFact(leftOP);
                            out.add(vul);
                        }
                    }
                }
                // END of Implementation
                return out;
            }
        };
    }

    @Override
    public FlowFunction<DataFlowFact> getReturnFlowFunction(Unit callSite, SootMethod callee, Unit exitStmt, Unit retSite) {
        return new FlowFunction<DataFlowFact>() {
            @Override
            public Set<DataFlowFact> computeTargets(DataFlowFact fact) {
                prettyPrint(callSite, fact);
                return Collections.emptySet();
            }
        };
    }
}
